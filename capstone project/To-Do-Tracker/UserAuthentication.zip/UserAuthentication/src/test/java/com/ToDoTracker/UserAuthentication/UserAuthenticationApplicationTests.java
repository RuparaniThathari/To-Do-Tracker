package com.ToDoTracker.UserAuthentication;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserAuthenticationApplicationTests {

	@Test
	void contextLoads() {
	}

}
